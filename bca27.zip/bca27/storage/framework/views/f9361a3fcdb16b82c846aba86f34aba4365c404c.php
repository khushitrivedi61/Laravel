
<html>
<head>
    <title>Salary Calculator</title>
</head>
<body>
    <h1>Salary Calculator</h1>

    <form action="<?php echo e(url('/salary')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Enter Basic Salary:</label>
        <input type="number" name="basic" step="any" required>
        <br><br>

        <label>Enter Allowance:</label>
        <input type="number" name="allowance" step="any" required>
        <br><br>

        <label>Enter Deduction:</label>
        <input type="number" name="deduction" step="any" required>
        <br><br>

        <button type="submit">Calculate Salary</button>
    </form>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(isset($salary)): ?>
        <h2>Net Salary = <?php echo e($salary); ?></h2>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\bca27\bca27\resources\views/salary.blade.php ENDPATH**/ ?>
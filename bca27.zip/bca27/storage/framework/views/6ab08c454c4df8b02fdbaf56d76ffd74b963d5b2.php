<html>
<head>
    <title>Mobile Shop</title>
</head>
<body>

    <h2>Mobile Shop</h2>

    <form action="<?php echo e(route('mobiles')); ?>" method="GET">

        <label>Select Company:</label>

        <select name="company" id="company" required>
            <option value="">-- Select Company --</option>

            <option value="Apple"
                <?php echo e($company == 'Apple' ? 'selected' : ''); ?>>
                Apple
            </option>

            <option value="Samsung"
                <?php echo e($company == 'Samsung' ? 'selected' : ''); ?>>
                Samsung
            </option>

            <option value="Oppo"
                <?php echo e($company == 'Oppo' ? 'selected' : ''); ?>>
                Oppo
            </option>

            <option value="Vivo"
                <?php echo e($company == 'Vivo' ? 'selected' : ''); ?>>
                Vivo
            </option>
        </select>

        <br><br>

        <label>Select Mobile Model:</label>

        <select name="model" id="model" required>
            <option value="">-- Select Model --</option>
        </select>

        <br><br>

        <button type="submit">Check Status</button>

    </form>

    <?php if(request()->filled('company') &&
        request()->filled('model')): ?>

        <h3>Mobile Details</h3>

        <?php if(count($results) > 0): ?>

            <table border="1">
                <tr>
                    <th>Mobile ID</th>
                    <th>Mobile Name</th>
                    <th>Company Name</th>
                    <th>Price</th>
                    <th>Stock Status</th>
                </tr>

                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mobile['id']); ?></td>
                        <td><?php echo e($mobile['name']); ?></td>
                        <td><?php echo e($mobile['company']); ?></td>
                        <td><?php echo e($mobile['price']); ?></td>
                        <td>
                            <?php if($mobile['stock'] == 'Available'): ?>
                                Available
                            <?php else: ?>
                                Out of Stock
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

        <?php else: ?>
            <p>No matching mobile found for the selected company and model.</p>
        <?php endif; ?>

    <?php endif; ?>

    <script>
        const models = {
            Apple: ['iPhone 15', 'iPhone 16'],
            Samsung: ['Galaxy S24', 'Galaxy A55'],
            Oppo: ['Oppo Reno 12', 'Oppo A3 Pro'],
            Vivo: ['Vivo V30', 'Vivo Y28']
        };

        const companySelect = document.getElementById('company');
        const modelSelect = document.getElementById('model');

        const selectedModel = <?php echo json_encode($model, 15, 512) ?>;

        function loadModels() {
            const company = companySelect.value;

            modelSelect.innerHTML =
                '<option value="">-- Select Model --</option>';

            if (models[company]) {
                models[company].forEach(function (model) {
                    const option = document.createElement('option');

                    option.value = model;
                    option.textContent = model;

                    if (model === selectedModel) {
                        option.selected = true;
                    }

                    modelSelect.appendChild(option);
                });
            }
        }

        companySelect.addEventListener('change', function () {
            loadModels();
        });

        loadModels();
    </script>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\bca27\bca27\resources\views/mobiles.blade.php ENDPATH**/ ?>
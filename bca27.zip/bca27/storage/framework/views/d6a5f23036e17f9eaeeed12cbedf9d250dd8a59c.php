
<html>
<head>
    <title>Product Details</title>
</head>
<body>

    <h1>Product Calculator</h1>

    <form action="<?php echo e(url('/product')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        Product Name:
        <input type="text" name="name" required>
        <br><br>

        Product Price:
        <input type="number" name="price" required>
        <br><br>

        Quantity:
        <input type="number" name="quantity" required>
        <br><br>

        <button type="submit">Calculate</button>
    </form>

    <?php if(isset($total)): ?>
        <h2>Product Details</h2>
        <p>Name: <?php echo e($name); ?></p>
        <p>Price: <?php echo e($price); ?></p>
        <p>Quantity: <?php echo e($quantity); ?></p>
        <h3>Total Amount: <?php echo e($total); ?></h3>
    <?php endif; ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\bca27\bca27\resources\views/product.blade.php ENDPATH**/ ?>